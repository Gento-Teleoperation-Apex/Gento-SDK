# generate_sdk.sh 使用说明

`generate_sdk.sh` 用于在 Linux 下自动编译 Gento SDK，并生成可安装的 Debian 包。

默认执行时会完成三件事：

1. 自动查找并运行 `linux_auto_compile.sh`
2. 编译生成 `libGentoSDK.so` 和 `libGentoSDKPY.so`
3. 把 C SDK 头文件、`libGentoSDK.so` 和 `gento-sdk-version` 打成 `.deb`

## 快速使用

在仓库根目录执行：

```bash
./SDK_generate_tools/generate_sdk.sh
```

当前目录结构下，脚本会自动找到：

```text
SDK_00040403_260604/SDK/00040400/linux_auto_compile.sh
SDK_00040403_260604/SDK/00040400/C_SDK
```

生成的 deb 默认放在仓库根目录，例如：

```text
gento-sdk_4.4.0_amd64.deb
```

安装：

```bash
sudo apt install ./gento-sdk_4.4.0_amd64.deb
```

安装后验证：

```bash
gento-sdk-version
```

## 依赖

需要系统里有：

```bash
sudo apt install build-essential dpkg-dev
```

其中：

- `g++` 用于编译 SDK 动态库和 `gento-sdk-version`
- `dpkg-deb` 用于生成 `.deb` 包

## 常用参数

### 指定输出目录

```bash
./SDK_generate_tools/generate_sdk.sh --output-dir dist
```

生成结果示例：

```text
dist/gento-sdk_4.4.0_amd64.deb
```

### 跳过自动编译，只打包现有 so

```bash
./SDK_generate_tools/generate_sdk.sh --no-compile
```

适用于已经手动运行过 `linux_auto_compile.sh`，只想重新生成 deb 的情况。

### 指定 SDK 根目录

`--sdk-root` 指向 `C_SDK` 目录：

```bash
./SDK_generate_tools/generate_sdk.sh --sdk-root SDK_00040403_260604/SDK/00040400/C_SDK
```

### 指定编译脚本

```bash
./SDK_generate_tools/generate_sdk.sh --compile-script SDK_00040403_260604/SDK/00040400/linux_auto_compile.sh
```

### 指定安装前缀

默认安装到 `/usr/local`：

```text
/usr/local/include/gentosdk
/usr/local/lib/libGentoSDK.so
/usr/local/bin/gento-sdk-version
```

如果希望 deb 安装到其他路径，例如 `/opt/gentosdk`：

```bash
./SDK_generate_tools/generate_sdk.sh --prefix /opt/gentosdk
```

安装后使用 CMake 时可指定：

```bash
GENTO_SDK_ROOT=/opt/gentosdk colcon build --packages-select marvin_ros_control
```

### 指定包名或版本号

```bash
./SDK_generate_tools/generate_sdk.sh --package-name gento-sdk --package-version 00040400
```

如果不指定 `--package-version`，当前脚本会优先从：

```text
C_SDK/Common/FXCommon.h
```

读取：

```c
FX_SDK_MAJOR_VERSION
FX_SDK_MINOR_VERSION
FX_SDK_PATCH_VERSION
```

并生成类似 `4.4.0` 的 deb 版本号。

如果没有读到这些宏，才会从路径里的 SDK 目录名，例如 `SDK/00040400/C_SDK`，取 `00040400` 作为版本号。

## 直接安装模式

除了生成 deb，也可以直接安装到本机：

```bash
./SDK_generate_tools/generate_sdk.sh --install
```

如果默认安装到 `/usr/local`，通常需要 sudo 权限；脚本会在需要时调用 `sudo`。

## 查看已安装版本

```bash
./SDK_generate_tools/generate_sdk.sh --version
```

该命令会调用已安装的：

```text
/usr/local/bin/gento-sdk-version
```

如果还没有安装，会提示先安装。

## 典型流程

```bash
./SDK_generate_tools/generate_sdk.sh
sudo apt install ./gento-sdk_4.4.0_amd64.deb
gento-sdk-version
```

如果需要用 `00040400` 作为 deb 版本号：

```bash
./SDK_generate_tools/generate_sdk.sh --package-version 00040400
sudo apt install ./gento-sdk_00040400_amd64.deb
```
