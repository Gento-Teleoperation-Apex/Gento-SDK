#ifndef FX_FXKINEMATICS_H_
#define FX_FXKINEMATICS_H_

#include "PointSet.h"
#include "FXMath.h"

#ifdef __cplusplus
extern "C"
{
#endif

#define  MAX_RUN_ROBOT_NUM 10

enum FX_ROBOT_TYPES
{
	FX_ROBOT_TYPE_DL = 1006,
	FX_ROBOT_TYPE_PILOT_SRS = 1007,
	FX_ROBOT_TYPE_PILOT_CCS = 1017,

	FX_ROBOT_TYPE_AXIS_5 = 2001,
};

enum FX_PILOT_NSP_TYPES
{
	FX_PILOT_NSP_TYPES_NEAR_REF = 0,
	FX_PILOT_NSP_TYPES_NEAR_DIR = 1,
};

enum FX_ROTATION_TYPE
{
	FX_ROT_NULL = 11,

	FX_ROT_EULER_XYZ = 101,
	FX_ROT_EULER_XZY = 102,
	FX_ROT_EULER_YXZ = 103,
	FX_ROT_EULER_YZX = 104,
	FX_ROT_EULER_ZXY = 105,
	FX_ROT_EULER_ZYX = 106,
					   
	FX_ROT_EULER_XYX = 107,
	FX_ROT_EULER_XZX = 108,
	FX_ROT_EULER_YXY = 109,
	FX_ROT_EULER_YZY = 110,
	FX_ROT_EULER_ZXZ = 111,
	FX_ROT_EULER_ZYZ = 112,

	FX_ROT_FIXED_XYZ = 201,
	FX_ROT_FIXED_XZY = 202,
	FX_ROT_FIXED_YXZ = 203,
	FX_ROT_FIXED_YZX = 204,
	FX_ROT_FIXED_ZXY = 205,
	FX_ROT_FIXED_ZYX = 206,
			
	FX_ROT_FIXED_XYX = 207,
	FX_ROT_FIXED_XZX = 208,
	FX_ROT_FIXED_YXY = 209,
	FX_ROT_FIXED_YZY = 210,
	FX_ROT_FIXED_ZXZ = 211,
	FX_ROT_FIXED_ZYZ = 212,
};

typedef struct
{
	/////////////////////////////// Kinematic
	//////// Kinematic Config
	Matrix4   m_AxisRotBase[7];
	Matrix4   m_Flange;
	Matrix4   m_InvFlange;
	Matrix4   m_FlangeTip;
	Matrix4   m_Tool;
	Matrix4   m_InvTool;
	//////// Kinematic Calculate
	Matrix4   m_TCP;
	Matrix4   m_JointPG[7];
	Matrix4   m_AxisRotTip[7];
	///////////////////////////////
}FX_KineBase;


typedef struct
{
	FX_DOUBLE m_JLmtPos_P[7];
	FX_DOUBLE m_JLmtPos_N[7];
	FX_DOUBLE m_JLmtVel[7];
	FX_DOUBLE m_JLmtAcc[7];
}FX_RobotLmt;

typedef struct
{
	/////////////////////////////// Dynamic
	//////// Dynamic Config
	FX_DOUBLE	m_JntMass[8];
	Vect3		m_JntMCP[8];
	Matrix3		m_JntInertia[8];
	FX_DOUBLE   m_ToolMass;
	Vect3		m_ToolMCP;
	Matrix3		m_ToolInertia;

	FX_BOOL     m_NToolTag;
	FX_DOUBLE   m_NToolMass;
	Vect3		m_NToolMCP;
	Matrix3		m_NToolInertia;

	FX_BOOL     m_BaseFloatationTag;
	Matrix3     m_BaseFloatationGes;
	Vect3       m_BaseFloatationOmg_Dir;
	FX_DOUBLE   m_BaseFloatationOmg_Val;
	Vect3       m_BaseFloatationOmgD_Dir;
	FX_DOUBLE   m_BaseFloatationOmgD_Val;
	Vect3       m_BaseFloatationAcc;
	Vect3		m_CalGravity;
	Vect3		m_SettingGravity;

	FX_BOOL     m_BaseFloatationOmg_Deg_Tag;
	FX_BOOL     m_BaseFloatationOmgD_Deg_Tag;

	//////// Dynamic Calculate

	Vect3		m_JntRotAxisDir_inBase[8];
	Matrix3     m_JntInertia_inBase[8];
	Matrix3     m_ToolInertia_inBase;
	Matrix3     m_NToolInertia_inBase;
	Vect3       m_JntMCP_inBase[8];
	Vect3       m_ToolMCP_inBase;
	Vect3       m_NToolMCP_inBase;

	Vect3		m_OMG[8];
	Vect3		m_OMGd[8];
	Vect3		m_Acc[8];
	Vect3		m_AccMC[8];
	Vect3       m_ToolAccMC;
	Vect3       m_NToolAccMC;

	Vect3       m_NToolDynF_inBase;
	Vect3       m_NToolDynN_inBase;

	Vect3       m_ToolDynF_inBase;
	Vect3       m_ToolDynN_inBase;
	Vect3       m_JntF_inBase[8];
	Vect3       m_JntN_inBase[8];

	Vect3       m_Link_F_inBase[8];
	Vect3       m_Link_N_inBase[8];

}FX_DynBase;

typedef struct
{
	FX_INT32		m_RobotType;
	FX_INT32		m_RobotDOF;
	FX_DOUBLE       m_RobotDH[8][4];
	FX_KineBase		m_KineBase;
	FX_RobotLmt		m_Lmt;
	FX_DynBase		m_DynaBase;
	FX_VOID*		m_KineSPC;
}FX_Robot;


typedef struct
{
	FX_BOOL	  m_IsCorss;
	FX_INT32  j4type;
	FX_DOUBLE j4v;
	FX_DOUBLE wristges[3][3];

    FX_DOUBLE rot_m[3][3];
	FX_DOUBLE rot_axis[3];
	FX_DOUBLE j123Base[3][3];
	FX_DOUBLE j567Base[3][3];
}NSPBase;

typedef struct
{
	FX_BOOL		m_IsCross;
	FX_DOUBLE	L1;
	FX_DOUBLE	L2;
	FX_DOUBLE	Ang1;
	FX_DOUBLE	Ang2;
	FX_DOUBLE	Angt;
	FX_DOUBLE	cart_len;
	FX_DOUBLE   m_J4_Bound;

	FX_DOUBLE lmtj67_pp[3];
	FX_DOUBLE lmtj67_np[3];
	FX_DOUBLE lmtj67_nn[3];
	FX_DOUBLE lmtj67_pn[3];

	NSPBase   m_nsp;

}FX_KineSPC_Pilot;


typedef struct
{
	FX_BOOL		m_PAD;

}FX_KineSPC_DL;

typedef struct
{
	FX_INT32 m_AxisNum;
	FX_DOUBLE m_Jcb[6][7];
}FX_Jacobi;

typedef struct
{
	Matrix4					m_Input_IK_TargetTCP;
	Vect7					m_Input_IK_RefJoint;
	FX_INT32				m_Input_IK_ZSPType;
	FX_DOUBLE				m_Input_IK_ZSPPara[6];
	FX_DOUBLE				m_Input_ZSP_Angle;
	FX_DOUBLE               m_DGR1;
	FX_DOUBLE               m_DGR2;
	FX_DOUBLE               m_DGR3;
	/////////////////////////////////////
	Vect7	m_Output_RetJoint;
	Matrix8 m_OutPut_AllJoint;
	FX_INT32 m_OutPut_Result_Num;
	FX_BOOL m_Output_IsOutRange;
	FX_BOOL m_Output_IsDeg[7];
	FX_BOOL m_Output_JntExdTags[7];
	FX_DOUBLE m_Output_JntExdABS;
	FX_BOOL m_Output_IsJntExd;
	Vect7	m_Output_RunLmtP;
	Vect7	m_Output_RunLmtN;
}FX_InvKineSolvePara;

typedef struct
{
	Vect7 m_Input_Joint;
	Vect7 m_Input_JointVel;
	Vect7 m_Input_JointAcc;

	FX_BOOL m_Input_IsBaseMove;
	Vect3 m_Input_BaseOmg;
	Vect3 m_Input_BaseOmgD;
	Vect3 m_Input_BaseAcc;

	Vect3 m_Input_ExForce;
	Vect3 m_Input_ExTorque;

}FX_InvDynaSolvePara;

////////////////////////////////////////////////////////////////////////////////////////////////
FX_BOOL  FX_Robot_Init_Type(FX_INT32 RobotSerial, FX_INT32 RobotType);
FX_BOOL  FX_Robot_Init_Kine(FX_INT32 RobotSerial, FX_DOUBLE DH[8][4]);
FX_BOOL  FX_Robot_Init_Lmt(FX_INT32 RobotSerial, FX_DOUBLE PNVA[7][4], FX_DOUBLE J67[4][3]);
////////////////////////////////////////////////////////////////////////////////////////////////
FX_BOOL  FX_Robot_Tool_Set(FX_INT32 RobotSerial, Matrix4 tool);
FX_BOOL  FX_Robot_Tool_Rmv(FX_INT32 RobotSerial);
////////////////////////////////////////////////////////////////////////////////////////////////
FX_BOOL  FX_Robot_Kine_FK(FX_INT32 RobotSerial, FX_DOUBLE joints[7], Matrix4 pgos);
FX_BOOL  FX_Robot_Kine_FK_NSP(FX_INT32 RobotSerial, FX_DOUBLE joints[7], Matrix4 pgos, Matrix3 nspg);
FX_BOOL  FX_Robot_Kine_Jacb(FX_INT32 RobotSerial, FX_DOUBLE joints[7], FX_Jacobi* jcb);
FX_BOOL  FX_Robot_Kine_IK(FX_INT32 RobotSerial, FX_InvKineSolvePara *solve_para);
FX_BOOL  FX_Robot_Kine_IK_NSP(FX_INT32 RobotSerial, FX_InvKineSolvePara* solve_para);

#ifdef __cplusplus
}
// C++ only functions
#endif

#endif
